using Microsoft.AspNetCore.Components;
using Microsoft.AspNetCore.Components.Forms;
using UI.EmployerPortal.Razor.SharedComponents.Inputs;
using UI.EmployerPortal.Web.Features.ManageAccount.Models;

namespace UI.EmployerPortal.Web.Features.ManageAccount.Components;

/// <summary>
/// A reusable Blazor component for entering and editing address information.
/// Encapsulates the UI form fields, validation, and layout for addresses.
/// </summary>
public partial class AddressForm : ComponentBase
{
    /// <summary>
    /// The address model containing the data bound to the form fields.
    /// </summary>
    [Parameter, EditorRequired]
    public AddressFormModel FormModel { get; set; } = default!;

    /// <summary>
    /// The EditContext used by the EditForm to track validation state and changes.
    /// </summary>
    [Parameter, EditorRequired]
    public EditContext EditContext { get; set; } = default!;

    /// <summary>
    /// Indicates whether the form is currently in a saving state.
    /// When true, disables the submit button and changes its text.
    /// </summary>
    [Parameter]
    public bool IsSaving { get; set; }

    /// <summary>
    /// Indicates whether the user has attempted to submit the form.
    /// Useful for displaying conditional validation feedback.
    /// </summary>
    [Parameter]
    public bool FormSubmitted { get; set; }

    /// <summary>
    /// A list of form-level validation errors or API errors to display in a banner.
    /// </summary>
    [Parameter]
    public List<string> FormErrors { get; set; } = new();

    /// <summary>
    /// A list of field IDs corresponding to the validation errors, used for navigating to the field when an error is clicked.
    /// </summary>
    [Parameter]
    public List<string> FormFieldIds { get; set; } = new();

    /// <summary>
    /// Indicates whether the Address Type dropdown should be disabled (e.g., when editing certain address types).
    /// </summary>
    [Parameter]
    public bool IsAddressTypeDisabled { get; set; }

    /// <summary>
    /// Event triggered when the user successfully submits the valid form.
    /// </summary>
    [Parameter]
    public EventCallback OnSubmit { get; set; }

    /// <summary>
    /// Event triggered when the user clicks the cancel button.
    /// </summary>
    [Parameter]
    public EventCallback OnCancel { get; set; }

    /// <summary>
    /// Select options for the Address Type dropdown.
    /// </summary>
    [Parameter] public List<SelectOption> AddressTypeOptions { get; set; } = new();

    /// <summary>
    /// Select options for the Country dropdown.
    /// </summary>
    [Parameter] public List<SelectOption> CountryOptions { get; set; } = new();

    /// <summary>
    /// Select options for the State dropdown (US addresses).
    /// </summary>
    [Parameter] public List<SelectOption> StateOptions { get; set; } = new();

    /// <summary>
    /// Select options for the Province dropdown (Canadian addresses).
    /// </summary>
    [Parameter] public List<SelectOption> ProvinceOptions { get; set; } = new();

    /// <summary>
    /// Handles the Country dropdown change event. Updates <see cref="AddressFormModel.CountryAddressFormatCodeSK"/>
    /// immediately so the form layout switches to the correct fields, and clears
    /// any field values that do not apply to the newly selected country.
    /// </summary>
    /// <param name="value">The selected country string value (1=US, 2=Canada, 3=Other International).</param>
    private void HandleCountryChanged(string? value)
    {
        FormModel.CountryString = value;

        if (!int.TryParse(value, out var countryCode))
        {
            return;
        }

        FormModel.CountryAddressFormatCodeSK = countryCode;

        // Clear fields that don't apply to the new country
        if (countryCode == 1)
        {
            // Switching to US — clear Canada / International fields
            FormModel.ProvinceString = null;
            FormModel.ProvinceCodeSK = null;
            FormModel.CanadianPostalCode = null;
            FormModel.LineThreeAddress = null;
            FormModel.LineFourAddress = null;
        }
        else if (countryCode == 2)
        {
            // Switching to Canada — clear US / International fields
            FormModel.StateString = null;
            FormModel.StateCodeSK = null;
            FormModel.ZipCode = null;
            FormModel.ZipExtension = null;
            FormModel.LineThreeAddress = null;
            FormModel.LineFourAddress = null;
        }
        else
        {
            // Switching to Other International — clear US / Canada fields
            FormModel.StateString = null;
            FormModel.StateCodeSK = null;
            FormModel.ProvinceString = null;
            FormModel.ProvinceCodeSK = null;
            FormModel.ZipCode = null;
            FormModel.ZipExtension = null;
            FormModel.CanadianPostalCode = null;
            FormModel.CityName = null;
        }

        StateHasChanged();
    }
}
